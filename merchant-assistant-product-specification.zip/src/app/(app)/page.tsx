import Link from "next/link";
import { redirect } from "next/navigation";
import { requireAuth, can } from "@/lib/auth";
import { getDashboard } from "@/lib/queries";
import { fmtMoney, fmtDate, fmtTime, fmtQty } from "@/lib/money";
import { Card, Stat, Badge, Icon, Empty } from "@/components/ui";
import CloseDay from "@/components/CloseDay";

const QUICK_ACTIONS = [
  { href: "/pos", label: "بيع جديد", icon: "pos", tone: "bg-emerald-700 text-white" },
  { href: "/purchases", label: "شراء", icon: "purchase", tone: "bg-slate-900 text-white" },
  { href: "/expenses", label: "مصروف", icon: "expense", tone: "bg-white border border-slate-200 text-slate-700" },
  { href: "/customers", label: "قبض", icon: "coins", tone: "bg-white border border-slate-200 text-slate-700" },
  { href: "/suppliers", label: "دفع مورد", icon: "suppliers", tone: "bg-white border border-slate-200 text-slate-700" },
  { href: "/assistant", label: "قول للنظام", icon: "assistant", tone: "bg-indigo-700 text-white" },
];

export default async function DashboardPage() {
  const auth = await requireAuth();
  // الكاشير يشوف نقطة البيع مباشرة — الأرباح والخزنة للمدير وصاحب النشاط
  if (!can(auth.role, "reports")) redirect("/pos");
  const d = await getDashboard(auth.business.id);
  const greeting = d.hour < 12 ? "صباح الخير" : d.hour < 17 ? "نهارك سعيد" : "مساء الخير";
  const name = auth.user.name.split(" ")[0];

  return (
    <div className="fade-up space-y-5">
      {/* الترحيب */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-black text-slate-900">
            {greeting} يا {name} 👋
          </h1>
          <p className="mt-1 text-sm text-slate-500">{fmtDate(new Date())}</p>
        </div>
        {d.session ? (
          <CloseDay expected={d.session.expected} />
        ) : (
          <Link href="/cash" className="rounded-2xl bg-amber-500 px-5 py-3 text-sm font-black text-white shadow-sm transition hover:bg-amber-600">
            🔓 افتح الخزنة وابدأ اليوم
          </Link>
        )}
      </div>

      {/* الأرقام أولًا */}
      <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
        <Stat
          label="خزنة متوقعة"
          value={fmtMoney(d.session?.expected ?? 0)}
          hint={d.session ? `فتحها ${fmtTime(d.session.openedAt)}` : "الخزنة مقفولة"}
          tone="money"
          icon={<Icon name="cash" size={17} />}
          href="/cash"
        />
        <Stat
          label="مبيعات اليوم"
          value={fmtMoney(d.stats.todaySales)}
          hint={`${d.stats.todaySalesCount} فاتورة`}
          tone="good"
          icon={<Icon name="sales" size={17} />}
          href="/sales"
        />
        <Stat
          label="مصروفات اليوم"
          value={fmtMoney(d.stats.todayExpenses)}
          hint={`مشتريات ${fmtMoney(d.stats.todayPurchases)}`}
          tone="bad"
          icon={<Icon name="expense" size={17} />}
          href="/expenses"
        />
        <Stat
          label="لك عند العملاء"
          value={fmtMoney(d.stats.receivables)}
          hint={`عليك للموردين ${fmtMoney(d.stats.payables)}`}
          tone={d.stats.receivables > 0 ? "warn" : "default"}
          icon={<Icon name="customers" size={17} />}
          href="/customers"
        />
      </div>

      {/* إجراءات سريعة */}
      <div className="grid grid-cols-3 gap-2.5 sm:grid-cols-6">
        {QUICK_ACTIONS.map((a) => (
          <Link
            key={a.href}
            href={a.href}
            className={`flex flex-col items-center gap-2 rounded-2xl p-3.5 shadow-sm transition hover:-translate-y-0.5 hover:shadow ${a.tone}`}
          >
            <Icon name={a.icon} size={22} />
            <span className="text-xs font-black">{a.label}</span>
          </Link>
        ))}
      </div>

      {/* نبذة + تنبيهات */}
      <div className="grid gap-4 lg:grid-cols-2">
        <Card title="نبذة النهارده 🧭" icon={<Icon name="assistant" size={18} />}>
          <ul className="space-y-2.5 text-sm">
            <li className="flex justify-between gap-3">
              <span className="text-slate-500">مبيعات إمبارح</span>
              <b className="text-slate-800">{fmtMoney(d.stats.yesterdaySales)}</b>
            </li>
            <li className="flex justify-between gap-3">
              <span className="text-slate-500">متوسط آخر 7 أيام</span>
              <b className="text-slate-800">{fmtMoney(d.stats.weekAvgDaily)}/يوم</b>
            </li>
            <li className="flex justify-between gap-3">
              <span className="text-slate-500">ربح اليوم التقريبي</span>
              <b className={d.stats.gross >= 0 ? "text-emerald-700" : "text-red-600"}>{fmtMoney(d.stats.gross)}</b>
            </li>
            <li className="flex justify-between gap-3">
              <span className="text-slate-500">أصناف قاربت تخلص</span>
              <Badge tone={d.lowStock.length > 0 ? "amber" : "green"}>{d.lowStock.length}</Badge>
            </li>
          </ul>
        </Card>
        <Card title="محتاج انتباهك" icon={<Icon name="bell" size={18} />}>
          {d.alerts.length === 0 ? (
            <Empty icon="check" title="كله تمام ✅" desc="مفيش حاجة حرجة حاليًا — كمّل يومك." />
          ) : (
            <ul className="space-y-2.5">
              {d.alerts.map((a) => (
                <li key={a.id} className="flex gap-2.5 rounded-xl bg-slate-50 px-3.5 py-3">
                  <Badge tone={a.severity === "danger" ? "red" : a.severity === "warn" ? "amber" : "blue"} className="mt-0.5 shrink-0">
                    {a.severity === "danger" ? "!" : a.severity === "warn" ? "؟" : "i"}
                  </Badge>
                  <div className="min-w-0">
                    <p className="text-sm font-bold text-slate-800">{a.title}</p>
                    {a.body && <p className="mt-0.5 text-xs leading-4 text-slate-500">{a.body}</p>}
                    {a.href && (
                      <Link href={a.href} className="mt-1 inline-block text-[11px] font-black text-emerald-700 hover:underline">
                        راجعها ←
                      </Link>
                    )}
                  </div>
                </li>
              ))}
            </ul>
          )}
        </Card>
      </div>

      {/* نشاط اليوم + الأصناف */}
      <div className="grid gap-4 lg:grid-cols-3">
        <Card title="نشاط اليوم" icon={<Icon name="timeline" size={18} />} className="lg:col-span-2" pad={false}>
          {d.timeline.length === 0 ? (
            <Empty icon="timeline" title="لسه مفيش حركة النهارده" desc="أول عملية بيع هتظهر هنا فورًا." />
          ) : (
            <ul className="divide-y divide-slate-50">
              {d.timeline.map((t) => (
                <li key={t.id} className="flex items-start gap-3 px-5 py-3">
                  <span className="mt-0.5 shrink-0 rounded-full bg-emerald-100 px-2 py-0.5 text-[10px] font-black text-emerald-700">
                    {fmtTime(t.at)}
                  </span>
                  <div className="min-w-0">
                    <p className="text-sm font-bold text-slate-800">{t.summary}</p>
                    <p className="text-[11px] text-slate-400">{t.actorName}</p>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </Card>
        <div className="space-y-4">
          <Card title="الأكثر مبيعًا اليوم" icon={<Icon name="reports" size={18} />} pad={false}>
            {d.topProducts.length === 0 ? (
              <Empty icon="reports" title="مفيش بيانات" />
            ) : (
              <ul className="space-y-3 px-5 py-4">
                {d.topProducts.slice(0, 5).map((t, i) => {
                  const max = d.topProducts[0].revenue || 1;
                  return (
                    <li key={t.name}>
                      <div className="mb-1 flex items-center justify-between text-xs">
                        <b className="text-slate-700">{i + 1}. {t.name}</b>
                        <span className="text-slate-500">{fmtMoney(t.revenue)}</span>
                      </div>
                      <div className="h-1.5 overflow-hidden rounded-full bg-slate-100">
                        <div className="h-full rounded-full bg-emerald-500" style={{ width: `${Math.max(6, (t.revenue / max) * 100)}%` }} />
                      </div>
                    </li>
                  );
                })}
              </ul>
            )}
          </Card>
          {d.lowStock.length > 0 && (
            <Card title="قربت تخلص 📦" icon={<Icon name="products" size={18} />} pad={false}>
              <ul className="divide-y divide-slate-50">
                {d.lowStock.map((p) => (
                  <li key={p.id} className="flex items-center justify-between px-5 py-2.5 text-sm">
                    <span className="font-bold text-slate-700">{p.name}</span>
                    <Badge tone={p.qty < 0 ? "red" : "amber"}>
                      {p.qty < 0 ? `سالب ${fmtQty(-p.qty)}` : `باقي ${fmtQty(p.qty)}`}
                    </Badge>
                  </li>
                ))}
              </ul>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}
