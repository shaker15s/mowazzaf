import { requireAuth, can } from "@/lib/auth";
import { getSalesPage } from "@/lib/queries";
import SalesClient from "@/components/SalesClient";

export default async function SalesPage() {
  const auth = await requireAuth();
  const sales = await getSalesPage(auth.business.id);
  return (
    <SalesClient
      sales={sales}
      canVoid={can(auth.role, "void_sale")}
      canReturn={can(auth.role, "return_sale")}
    />
  );
}
