import { requireAuth, can } from "@/lib/auth";
import { getProductsPage } from "@/lib/queries";
import ProductsClient from "@/components/ProductsClient";

export default async function ProductsPage() {
  const auth = await requireAuth();
  const data = await getProductsPage(auth.business.id);
  return <ProductsClient data={data} canEdit={can(auth.role, "products")} />;
}
