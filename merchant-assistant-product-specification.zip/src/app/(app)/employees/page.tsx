import { requireAuth, can } from "@/lib/auth";
import { getEmployeesPage } from "@/lib/queries";
import { Card, Icon, Empty, Badge } from "@/components/ui";
import EmployeesClient from "@/components/EmployeesClient";

export default async function EmployeesPage() {
  const auth = await requireAuth();
  if (!can(auth.role, "employees")) {
    return (
      <div className="fade-up">
        <Card>
          <Empty icon="alert" title="غير مصرح لك" desc="إدارة الموظفين متاحة لصاحب النشاط فقط." />
        </Card>
      </div>
    );
  }
  const employees = await getEmployeesPage(auth.business.id);
  return <EmployeesClient employees={employees} currentUserId={auth.user.id} />;
}
