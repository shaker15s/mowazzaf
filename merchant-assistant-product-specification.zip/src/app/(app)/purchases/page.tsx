import { requireAuth, can } from "@/lib/auth";
import { getPurchasesPage, getProductsPage, getSuppliersPage } from "@/lib/queries";
import PurchasesClient from "@/components/PurchasesClient";

export default async function PurchasesPage() {
  const auth = await requireAuth();
  const purchases = await getPurchasesPage(auth.business.id);
  const products = await getProductsPage(auth.business.id);
  const suppliers = await getSuppliersPage(auth.business.id);
  return (
    <PurchasesClient
      purchases={purchases}
      canCreate={can(auth.role, "purchases")}
      products={products.products.map((p) => ({ id: p.id, name: p.name, costPrice: p.costPrice }))}
      suppliers={suppliers.map((s) => ({ id: s.id, name: s.name, balance: s.balance }))}
    />
  );
}
