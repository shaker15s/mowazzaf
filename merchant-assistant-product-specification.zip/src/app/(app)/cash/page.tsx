import { requireAuth, can } from "@/lib/auth";
import { getCashPage } from "@/lib/queries";
import CashClient from "@/components/CashClient";

export default async function CashPage() {
  const auth = await requireAuth();
  const data = await getCashPage(auth.business.id);
  return <CashClient data={data} canManage={can(auth.role, "cash")} />;
}
