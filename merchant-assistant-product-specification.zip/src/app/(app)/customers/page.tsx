import Link from "next/link";
import { requireAuth } from "@/lib/auth";
import { getCustomersPage } from "@/lib/queries";
import { fmtMoney } from "@/lib/money";
import { Card, Icon, Empty, Badge } from "@/components/ui";
import CustomersClient from "@/components/CustomersClient";

export default async function CustomersPage() {
  const auth = await requireAuth();
  const customers = await getCustomersPage(auth.business.id);
  const totalDebt = customers.reduce((s, c) => s + (c.balance > 0 ? c.balance : 0), 0);

  return (
    <div className="fade-up space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-black text-slate-900">العملاء</h1>
          <p className="mt-0.5 text-sm text-slate-500">
            لك عندهم: <b className="text-amber-600">{fmtMoney(totalDebt)}</b>
          </p>
        </div>
        <CustomersClient />
      </div>

      <Card pad={false}>
        {customers.length === 0 ? (
          <Empty icon="customers" title="مفيش عملاء لسه" desc="أضف أول عميل عشان تقدر تبيع له آجل." />
        ) : (
          <ul className="divide-y divide-slate-50">
            {customers.map((c) => (
              <li key={c.id}>
                <Link href={`/customers/${c.id}`} className="flex items-center gap-3 px-5 py-4 transition hover:bg-slate-50/70">
                  <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-slate-100 text-sm font-black text-slate-500">
                    {c.name.charAt(0)}
                  </span>
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-black text-slate-800">{c.name}</p>
                    <p className="text-[11px] text-slate-400" dir="ltr">
                      {c.phone || "—"}
                    </p>
                  </div>
                  {c.creditLimit > 0 && <Badge tone="gray">حد: {fmtMoney(c.creditLimit)}</Badge>}
                  <div className="text-left">
                    <p className="text-[11px] text-slate-400">الرصيد</p>
                    <p className={`text-sm font-black ${c.balance > 0 ? "text-amber-600" : c.balance < 0 ? "text-emerald-700" : "text-slate-400"}`}>
                      {c.balance > 0 ? `عليه ${fmtMoney(c.balance)}` : c.balance < 0 ? `له ${fmtMoney(-c.balance)}` : "خالص"}
                    </p>
                  </div>
                  <Icon name="arrow" size={16} className="rotate-180 text-slate-300" />
                </Link>
              </li>
            ))}
          </ul>
        )}
      </Card>
    </div>
  );
}
