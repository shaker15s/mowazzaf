import Link from "next/link";
import { notFound } from "next/navigation";
import { requireAuth } from "@/lib/auth";
import { getCustomerDetail } from "@/lib/queries";
import { fmtMoney, fmtDateTime, fmtQty } from "@/lib/money";
import { Card, Icon, Badge, Empty } from "@/components/ui";
import CustomerPayment from "@/components/CustomerPayment";

const KIND_LABELS: Record<string, { label: string; tone: "green" | "red" | "blue" | "gray" }> = {
  sale: { label: "بيع آجل", tone: "red" },
  payment: { label: "دفعة", tone: "green" },
  return: { label: "مرتجع", tone: "blue" },
  void: { label: "إلغاء فاتورة", tone: "gray" },
};

export default async function CustomerDetailPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const auth = await requireAuth();
  const { id } = await params;
  const data = await getCustomerDetail(auth.business.id, Number(id));
  if (!data) notFound();
  const c = data.customer;

  return (
    <div className="fade-up space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <Link href="/customers" className="rounded-xl border border-slate-200 bg-white p-2.5 text-slate-500 transition hover:text-slate-800">
            <Icon name="arrow" size={17} className="rotate-180" />
          </Link>
          <div>
            <h1 className="text-2xl font-black text-slate-900">{c.name}</h1>
            <p className="text-xs text-slate-400" dir="ltr">{c.phone || "بدون رقم"}</p>
          </div>
        </div>
        <div className="text-left">
          <p className="text-xs text-slate-500">الرصيد الحالي</p>
          <p className={`text-xl font-black ${c.balance > 0 ? "text-amber-600" : c.balance < 0 ? "text-emerald-700" : "text-slate-400"}`}>
            {c.balance > 0 ? `عليه ${fmtMoney(c.balance)}` : c.balance < 0 ? `له ${fmtMoney(-c.balance)}` : "خالص ✔️"}
          </p>
        </div>
      </div>

      <CustomerPayment customerId={c.id} customerName={c.name} balance={c.balance} />

      <div className="grid gap-4 lg:grid-cols-2">
        <Card title="كشف الحساب" icon={<Icon name="sales" size={17} />} pad={false}>
          {data.ledger.length === 0 ? (
            <Empty icon="sales" title="مفيش حركات" />
          ) : (
            <ul className="divide-y divide-slate-50">
              {data.ledger.map((l) => {
                const meta = KIND_LABELS[l.kind] ?? { label: l.kind, tone: "gray" as const };
                return (
                  <li key={l.id} className="flex items-center gap-3 px-5 py-3">
                    <Badge tone={meta.tone}>{meta.label}</Badge>
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-sm text-slate-600">{l.note ?? "—"}</p>
                      <p className="text-[11px] text-slate-400">{fmtDateTime(l.at)}</p>
                    </div>
                    <b className={`text-sm ${l.amount > 0 ? "text-red-600" : "text-emerald-700"}`}>
                      {l.amount > 0 ? "+" : ""}
                      {fmtMoney(l.amount)}
                    </b>
                  </li>
                );
              })}
            </ul>
          )}
        </Card>

        <Card title="فواتيره" icon={<Icon name="pos" size={17} />} pad={false}>
          {data.sales.length === 0 ? (
            <Empty icon="pos" title="مفيش فواتير" />
          ) : (
            <ul className="divide-y divide-slate-50">
              {data.sales.map((s) => (
                <li key={s.id} className="flex items-center gap-3 px-5 py-3">
                  <Badge tone={s.status === "voided" ? "red" : "green"}>#{s.number}</Badge>
                  <div className="min-w-0 flex-1">
                    <p className="text-sm font-bold text-slate-700">{fmtMoney(s.total)}</p>
                    <p className="text-[11px] text-slate-400">
                      {fmtDateTime(s.at)} — {s.method === "credit" ? "آجل" : "مدفوع"}
                    </p>
                  </div>
                  {s.method === "credit" && s.paid < s.total && (
                    <Badge tone="amber">باقي {fmtMoney(s.total - s.paid)}</Badge>
                  )}
                </li>
              ))}
            </ul>
          )}
        </Card>
      </div>
      <p className="text-center text-[11px] text-slate-400">
        كل حركة في الكشف مرتبطة بالفاتورة أو الدفعة الأصلية — ومفيش تعديل صامت على الرصيد.
      </p>
    </div>
  );
}
