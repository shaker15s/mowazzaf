import { requireAuth, can } from "@/lib/auth";
import { getExpensesPage } from "@/lib/queries";
import ExpensesClient from "@/components/ExpensesClient";

export default async function ExpensesPage() {
  const auth = await requireAuth();
  const data = await getExpensesPage(auth.business.id);
  return <ExpensesClient data={data} canCreate={can(auth.role, "expenses")} />;
}
