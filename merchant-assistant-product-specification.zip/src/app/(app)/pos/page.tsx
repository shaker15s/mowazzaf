import { requireAuth } from "@/lib/auth";
import { getPosData } from "@/lib/queries";
import PosClient from "@/components/PosClient";

export default async function PosPage({
  searchParams,
}: {
  searchParams: Promise<{ customer?: string; quick?: string }>;
}) {
  const auth = await requireAuth();
  const params = await searchParams;
  const data = await getPosData(auth.business.id);
  return (
    <PosClient
      businessId={auth.business.id}
      role={auth.role}
      products={data.products}
      categories={data.categories}
      customers={data.customers}
      preselectCustomerId={params.customer ? Number(params.customer) : undefined}
      startQuick={params.quick === "1"}
    />
  );
}
