import Link from "next/link";
import { notFound } from "next/navigation";
import { requireAuth } from "@/lib/auth";
import { getSupplierDetail } from "@/lib/queries";
import { fmtMoney, fmtDateTime } from "@/lib/money";
import { Card, Icon, Badge, Empty } from "@/components/ui";
import SupplierPayment from "@/components/SupplierPayment";

const KIND_LABELS: Record<string, { label: string; tone: "green" | "red" | "blue" }> = {
  purchase: { label: "شراء", tone: "red" },
  payment: { label: "دفعة", tone: "green" },
  return: { label: "مرتجع شراء", tone: "blue" },
};

export default async function SupplierDetailPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const auth = await requireAuth();
  const { id } = await params;
  const data = await getSupplierDetail(auth.business.id, Number(id));
  if (!data) notFound();
  const s = data.supplier;

  return (
    <div className="fade-up space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <Link href="/suppliers" className="rounded-xl border border-slate-200 bg-white p-2.5 text-slate-500 transition hover:text-slate-800">
            <Icon name="arrow" size={17} className="rotate-180" />
          </Link>
          <div>
            <h1 className="text-2xl font-black text-slate-900">{s.name}</h1>
            <p className="text-xs text-slate-400" dir="ltr">{s.phone || "بدون رقم"}</p>
          </div>
        </div>
        <div className="text-left">
          <p className="text-xs text-slate-500">الرصيد الحالي</p>
          <p className={`text-xl font-black ${s.balance > 0 ? "text-red-600" : "text-emerald-700"}`}>
            {s.balance > 0 ? `عليك ${fmtMoney(s.balance)}` : "خالص ✔️"}
          </p>
        </div>
      </div>

      <SupplierPayment supplierId={s.id} supplierName={s.name} balance={s.balance} />

      <div className="grid gap-4 lg:grid-cols-2">
        <Card title="كشف الحساب" icon={<Icon name="sales" size={17} />} pad={false}>
          {data.ledger.length === 0 ? (
            <Empty icon="sales" title="مفيش حركات" />
          ) : (
            <ul className="divide-y divide-slate-50">
              {data.ledger.map((l) => {
                const meta = KIND_LABELS[l.kind] ?? { label: l.kind, tone: "blue" as const };
                return (
                  <li key={l.id} className="flex items-center gap-3 px-5 py-3">
                    <Badge tone={meta.tone}>{meta.label}</Badge>
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-sm text-slate-600">{l.note ?? "—"}</p>
                      <p className="text-[11px] text-slate-400">{fmtDateTime(l.at)}</p>
                    </div>
                    <b className={`text-sm ${l.amount > 0 ? "text-red-600" : "text-emerald-700"}`}>
                      {l.amount > 0 ? "+" : ""}
                      {fmtMoney(l.amount)}
                    </b>
                  </li>
                );
              })}
            </ul>
          )}
        </Card>

        <Card title="فواتير الشراء" icon={<Icon name="purchase" size={17} />} pad={false}>
          {data.purchases.length === 0 ? (
            <Empty icon="purchase" title="مفيش مشتريات" />
          ) : (
            <ul className="divide-y divide-slate-50">
              {data.purchases.map((p) => (
                <li key={p.id} className="flex items-center gap-3 px-5 py-3">
                  <Badge tone="gray">#{p.number}</Badge>
                  <div className="min-w-0 flex-1">
                    <p className="text-sm font-bold text-slate-700">{fmtMoney(p.total)}</p>
                    <p className="text-[11px] text-slate-400">{fmtDateTime(p.at)}</p>
                  </div>
                  {p.paid < p.total && <Badge tone="amber">باقي {fmtMoney(p.total - p.paid)}</Badge>}
                </li>
              ))}
            </ul>
          )}
        </Card>
      </div>
    </div>
  );
}
