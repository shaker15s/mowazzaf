import Link from "next/link";
import { requireAuth } from "@/lib/auth";
import { getSuppliersPage } from "@/lib/queries";
import { fmtMoney } from "@/lib/money";
import { Card, Icon, Empty, Badge } from "@/components/ui";
import SuppliersClient from "@/components/SuppliersClient";

export default async function SuppliersPage() {
  const auth = await requireAuth();
  const suppliers = await getSuppliersPage(auth.business.id);
  const totalPayable = suppliers.reduce((s, x) => s + (x.balance > 0 ? x.balance : 0), 0);

  return (
    <div className="fade-up space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-black text-slate-900">الموردون</h1>
          <p className="mt-0.5 text-sm text-slate-500">
            عليك لهم: <b className="text-red-600">{fmtMoney(totalPayable)}</b>
          </p>
        </div>
        <SuppliersClient />
      </div>

      <Card pad={false}>
        {suppliers.length === 0 ? (
          <Empty icon="suppliers" title="مفيش موردين لسه" desc="أضف أول مورد عشان تسجل الشراء الآجل." />
        ) : (
          <ul className="divide-y divide-slate-50">
            {suppliers.map((s) => (
              <li key={s.id}>
                <Link href={`/suppliers/${s.id}`} className="flex items-center gap-3 px-5 py-4 transition hover:bg-slate-50/70">
                  <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-slate-900 text-sm font-black text-white">
                    {s.name.charAt(0)}
                  </span>
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-black text-slate-800">{s.name}</p>
                    <p className="text-[11px] text-slate-400" dir="ltr">
                      {s.phone || "—"}
                    </p>
                  </div>
                  <div className="text-left">
                    <p className="text-[11px] text-slate-400">الرصيد</p>
                    <p className={`text-sm font-black ${s.balance > 0 ? "text-red-600" : "text-emerald-700"}`}>
                      {s.balance > 0 ? `عليك ${fmtMoney(s.balance)}` : "خالص"}
                    </p>
                  </div>
                  <Icon name="arrow" size={16} className="rotate-180 text-slate-300" />
                </Link>
              </li>
            ))}
          </ul>
        )}
      </Card>
      <p className="text-center text-xs text-slate-400">
        <Badge tone="gray">ملحوظة</Badge> الشراء الآجل يزيد رصيد المورد، والدفع يخفضه — وكل حركة ليها سجل.
      </p>
    </div>
  );
}
