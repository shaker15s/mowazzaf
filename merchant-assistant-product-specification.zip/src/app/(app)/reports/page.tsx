import { requireAuth, can } from "@/lib/auth";
import { getReportsPage } from "@/lib/queries";
import { fmtMoney, fmtQty } from "@/lib/money";
import { Card, Icon, Stat, Badge, Empty } from "@/components/ui";

const RANGES = [
  { days: 1, label: "اليوم" },
  { days: 7, label: "آخر 7 أيام" },
  { days: 30, label: "آخر 30 يوم" },
];

export default async function ReportsPage({
  searchParams,
}: {
  searchParams: Promise<{ days?: string }>;
}) {
  const auth = await requireAuth();
  if (!can(auth.role, "reports")) {
    return (
      <div className="fade-up">
        <Card>
          <Empty icon="alert" title="غير مصرح لك" desc="التقارير والأرباح متاحة للمدير وصاحب النشاط فقط." />
        </Card>
      </div>
    );
  }
  const params = await searchParams;
  const days = Math.min(90, Math.max(1, Number(params.days) || 1));
  const r = await getReportsPage(auth.business.id, days);
  const trend =
    r.prev.sales > 0 ? ((r.summary.sales - r.prev.sales) / r.prev.sales) * 100 : 0;

  return (
    <div className="fade-up space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-black text-slate-900">التقارير</h1>
          <p className="mt-0.5 text-sm text-slate-500">أرقام حقيقية محسوبة من الدفاتر — بدون تخمين</p>
        </div>
        <div className="flex rounded-xl border border-slate-200 bg-white p-1">
          {RANGES.map((x) => (
            <a
              key={x.days}
              href={`/reports?days=${x.days}`}
              className={`rounded-lg px-4 py-1.5 text-xs font-black transition ${days === x.days ? "bg-slate-900 text-white" : "text-slate-500 hover:text-slate-800"}`}
            >
              {x.label}
            </a>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
        <Stat
          label="المبيعات"
          value={fmtMoney(r.summary.sales)}
          hint={`${r.summary.count} فاتورة`}
          tone="good"
          icon={<Icon name="sales" size={17} />}
        />
        <Stat
          label="المشتريات"
          value={fmtMoney(r.purchases.total)}
          hint={`${r.purchases.count} عملية — مدفوع ${fmtMoney(r.purchases.paid)}`}
          icon={<Icon name="purchase" size={17} />}
        />
        <Stat
          label="المصروفات"
          value={fmtMoney(r.totalExpenses)}
          icon={<Icon name="expense" size={17} />}
          tone="bad"
        />
        <Stat
          label="الربح التقريبي"
          value={fmtMoney(r.net)}
          hint={`إجمالي ${fmtMoney(r.gross)} - المصروفات`}
          tone={r.net >= 0 ? "money" : "bad"}
          icon={<Icon name="coins" size={17} />}
        />
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        <Card title="تقسيم المبيعات" icon={<Icon name="reports" size={17} />}>
          <ul className="space-y-2.5 text-sm">
            <li className="flex justify-between"><span className="text-slate-500">نقدي</span><b>{fmtMoney(r.summary.cash)}</b></li>
            <li className="flex justify-between"><span className="text-slate-500">آجل (على العملاء)</span><b className="text-amber-600">{fmtMoney(r.summary.credit)}</b></li>
            <li className="flex justify-between"><span className="text-slate-500">مرتجعات</span><b className="text-red-600">-{fmtMoney(r.summary.returns)}</b></li>
            <li className="flex justify-between"><span className="text-slate-500">تحصيلات</span><b className="text-emerald-700">{fmtMoney(r.collections)}</b></li>
            <li className="flex justify-between"><span className="text-slate-500">مدفوعات للموردين</span><b className="text-red-600">-{fmtMoney(r.supplierPayments)}</b></li>
            <li className="mt-2 flex justify-between border-t border-slate-100 pt-2">
              <span className="text-slate-500">المقارنة بالفترة السابقة</span>
              <Badge tone={trend >= 0 ? "green" : "red"}>
                {trend >= 0 ? "▲" : "▼"} {Math.abs(trend).toFixed(0)}%
              </Badge>
            </li>
          </ul>
        </Card>

        <Card title="المصروفات حسب النوع" icon={<Icon name="expense" size={17} />}>
          {r.expensesByCategory.length === 0 ? (
            <Empty icon="expense" title="مفيش مصروفات في الفترة" />
          ) : (
            <ul className="space-y-2.5">
              {r.expensesByCategory.map((e) => {
                const max = r.expensesByCategory[0].total || 1;
                return (
                  <li key={e.category}>
                    <div className="mb-1 flex justify-between text-xs">
                      <b className="text-slate-600">{e.category}</b>
                      <span className="text-slate-500">{fmtMoney(e.total)}</span>
                    </div>
                    <div className="h-1.5 overflow-hidden rounded-full bg-slate-100">
                      <div className="h-full rounded-full bg-red-400" style={{ width: `${Math.max(6, (e.total / max) * 100)}%` }} />
                    </div>
                  </li>
                );
              })}
            </ul>
          )}
        </Card>
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        <Card title="الأكثر مبيعًا" icon={<Icon name="reports" size={17} />} pad={false}>
          {r.topProducts.length === 0 ? (
            <Empty icon="reports" title="مفيش مبيعات" />
          ) : (
            <ul className="divide-y divide-slate-50">
              {r.topProducts.slice(0, 6).map((t, i) => (
                <li key={t.name} className="flex items-center gap-3 px-5 py-3">
                  <span className="text-sm font-black text-slate-400">{i + 1}</span>
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-bold text-slate-700">{t.name}</p>
                    <p className="text-[11px] text-slate-400">{fmtQty(t.qty)} وحدة مباعة</p>
                  </div>
                  <b className="text-sm text-slate-800">{fmtMoney(t.revenue)}</b>
                </li>
              ))}
            </ul>
          )}
        </Card>

        <Card title="المخزون" icon={<Icon name="products" size={17} />}>
          <ul className="space-y-2.5 text-sm">
            <li className="flex justify-between"><span className="text-slate-500">قيمة المخزون (بالتكلفة)</span><b>{fmtMoney(r.stockValue)}</b></li>
            <li className="flex justify-between"><span className="text-slate-500">أصناف راكدة (مفيش مبيعات في الفترة)</span><b className="text-amber-600">{r.deadStock.length}</b></li>
          </ul>
          {r.deadStock.length > 0 && (
            <ul className="mt-3 space-y-1.5">
              {r.deadStock.map((d) => (
                <li key={d.id} className="flex justify-between rounded-lg bg-slate-50 px-3 py-2 text-xs">
                  <span className="font-bold text-slate-600">{d.name}</span>
                  <span className="text-slate-400">{fmtQty(d.qty)} وحدة</span>
                </li>
              ))}
            </ul>
          )}
        </Card>
      </div>
    </div>
  );
}
