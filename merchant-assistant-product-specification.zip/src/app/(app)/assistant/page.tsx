"use client";

import { useEffect, useRef, useState } from "react";
import { Icon, Spinner, Btn } from "@/components/ui";

type Msg = {
  role: "user" | "assistant";
  text: string;
  confirmation?: Record<string, unknown> & { op: string; label?: string };
  executed?: boolean;
};

const CHIPS = [
  "بعت كام النهارده؟",
  "مين عليه فلوس؟",
  "إيه اللي قرب يخلص؟",
  "الخزنة فيها كام؟",
  "محمد دفع 500 من حسابه",
  "سجل مصروف كهرباء 300",
  "اعمللي ملخص النهارده",
];

export default function AssistantPage() {
  const [messages, setMessages] = useState<Msg[]>([
    {
      role: "assistant",
      text: "أهلًا 👋 أنا موظفك الرقمي.\n\nبشوف بيانات محلك الحقيقية وبسجل العمليات بعد تأكيدك. اسألني أي حاجة أو قولّي اللي حصل في المحل بطريقتك.",
    },
  ]);
  const [input, setInput] = useState("");
  const [busy, setBusy] = useState(false);
  const endRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const send = async (
    text: string,
    confirm?: Record<string, unknown> & { op: string },
    confirmIndex?: number,
  ) => {
    if (busy) return;
    setBusy(true);
    setMessages((m) => {
      let next = [...m];
      if (confirm) {
        if (confirmIndex !== undefined) {
          next[confirmIndex] = { ...next[confirmIndex], executed: true, confirmation: undefined };
        }
        next = [...next, { role: "user", text: "نفّذ العملية ✅" }];
      } else {
        next = [...next, { role: "user", text }];
      }
      return next;
    });
    try {
      const res = await fetch("/api/assistant", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: confirm ? "(تنفيذ أمر مؤكد)" : text, confirm: confirm ?? null }),
      });
      const data = await res.json();
      if (data.reply) {
        setMessages((m) => [...m, { role: "assistant", text: data.reply, confirmation: data.confirmation }]);
      } else {
        setMessages((m) => [...m, { role: "assistant", text: data.error ?? "حصلت مشكلة — جرب تاني." }]);
      }
    } catch {
      setMessages((m) => [
        ...m,
        { role: "assistant", text: "مش عارف أوصل للخادم حاليًا — النظام الأساسي (البيع والخزنة) شغال عادي." },
      ]);
    }
    setBusy(false);
  };

  const confirmBtn = (m: Msg, idx: number) => (
    <div className="mt-3 flex flex-wrap gap-2">
      <Btn size="sm" onClick={() => send("", m.confirmation, idx)} disabled={busy}>
        <Icon name="check" size={14} />
        نفّذ العملية
      </Btn>
      <Btn
        size="sm"
        variant="ghost"
        onClick={() =>
          setMessages((prev) => {
            const next = [...prev];
            next[idx] = { ...next[idx], confirmation: undefined, executed: false };
            return next;
          })
        }
        disabled={busy}
      >
        إلغاء
      </Btn>
    </div>
  );

  return (
    <div className="fade-up flex h-[calc(100vh-8.5rem)] flex-col">
      <div className="mb-3 flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-black text-slate-900">المساعد 🧠</h1>
          <p className="mt-0.5 text-xs text-slate-500">
            يجيب من بيانات المحل الحقيقية — والعمليات الحساسة بتاخد تأكيدك الأول
          </p>
        </div>
        <span className="hidden items-center gap-1.5 rounded-full bg-emerald-50 px-3 py-1.5 text-[11px] font-black text-emerald-700 sm:flex">
          <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-emerald-500" />
          شغال على بياناتك مباشرة
        </span>
      </div>

      <div className="flex-1 space-y-3 overflow-y-auto rounded-2xl border border-slate-200 bg-white p-4 shadow-sm">
        {messages.map((m, i) => (
          <div key={i} className={`flex ${m.role === "user" ? "justify-start" : "justify-end"}`}>
            <div
              className={`max-w-[85%] whitespace-pre-wrap rounded-2xl px-4 py-3 text-sm leading-6 shadow-sm sm:max-w-[70%] ${
                m.role === "user"
                  ? "rounded-tr-sm bg-slate-900 text-white"
                  : "rounded-tl-sm border border-slate-200 bg-slate-50 text-slate-800"
              }`}
            >
              {m.text}
              {m.confirmation && !m.executed && confirmBtn(m, i)}
              {m.executed && (
                <p className="mt-2 text-[11px] text-slate-400">تم التنفيذ من قِبل النظام بعد تأكيدك</p>
              )}
            </div>
          </div>
        ))}
        {busy && (
          <div className="flex justify-end">
            <div className="flex items-center gap-2 rounded-2xl rounded-tl-sm bg-slate-50 px-4 py-3 text-xs font-bold text-slate-400">
              <Spinner size={14} />
              بشوف بيانات المحل…
            </div>
          </div>
        )}
        {messages.length <= 1 && (
          <div className="flex flex-wrap gap-2 pt-2">
            {CHIPS.map((c) => (
              <button
                key={c}
                onClick={() => send(c)}
                disabled={busy}
                className="rounded-full border border-slate-200 bg-white px-3.5 py-1.5 text-xs font-bold text-slate-600 transition hover:border-emerald-400 hover:text-emerald-700 disabled:opacity-50"
              >
                {c}
              </button>
            ))}
          </div>
        )}
        <div ref={endRef} />
      </div>

      <form
        className="mt-3 flex gap-2"
        onSubmit={(e) => {
          e.preventDefault();
          const t = input.trim();
          if (!t) return;
          setInput("");
          send(t);
        }}
      >
        <input
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="قول للنظام اللي حصل في محلك… مثال: سجل مصروف كهرباء 300"
          className="flex-1 rounded-2xl border border-slate-300 bg-white px-4 py-3.5 text-sm font-bold outline-none transition focus:border-emerald-600 focus:ring-2 focus:ring-emerald-600/20"
          disabled={busy}
        />
        <button
          type="submit"
          disabled={busy || !input.trim()}
          className="rounded-2xl bg-emerald-700 px-5 text-white transition hover:bg-emerald-800 disabled:opacity-50"
          aria-label="إرسال"
        >
          <Icon name="arrow" size={20} className="rotate-180" />
        </button>
      </form>
      <p className="mt-2 text-center text-[10px] text-slate-400">
        قاعدة البيانات هي مصدر الحقيقة — المساعد لا يخترع أرقامًا ولا يعدّل شيئًا بدون إذنك.
      </p>
    </div>
  );
}
