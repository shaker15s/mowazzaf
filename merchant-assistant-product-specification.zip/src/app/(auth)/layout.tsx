import { Logo } from "@/components/ui";

export default function AuthLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="relative flex min-h-screen items-center justify-center overflow-hidden bg-slate-950 px-4 py-10">
      <div className="pointer-events-none absolute inset-0">
        <div className="absolute -right-32 -top-32 h-96 w-96 rounded-full bg-emerald-600/20 blur-3xl" />
        <div className="absolute -bottom-32 -left-32 h-96 w-96 rounded-full bg-teal-500/10 blur-3xl" />
      </div>
      <div className="relative w-full max-w-md">
        <div className="mb-6 flex items-center justify-center gap-3">
          <Logo size={44} />
          <div>
            <h1 className="text-xl font-black text-white">مساعد التاجر</h1>
            <p className="text-xs text-slate-400">قول للنظام اللي حصل في محلك — وهو يسجل ويدير ويراجع</p>
          </div>
        </div>
        {children}
      </div>
    </div>
  );
}
