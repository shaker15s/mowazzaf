"use client";

import { useState } from "react";
import { Input, Btn, Icon } from "@/components/ui";
import { createBusiness } from "@/lib/engine";

const TYPES = [
  {
    id: "supermarket",
    name: "سوبر ماركت / بقالة",
    emoji: "🛒",
    desc: "منتجات كثيرة، باركود اختياري، بيع سريع باللمس",
  },
  {
    id: "attara",
    name: "عطارة / بيع بالوزن",
    emoji: "🌿",
    desc: "منتجات بالكيلو والجرام، حساب سريع للوزن والسعر",
  },
  {
    id: "general",
    name: "محل عام / ملابس",
    emoji: "🏬",
    desc: "أصناف متنوعة، مقاسات وألوان، مخزون اختياري",
  },
] as const;

export default function OnboardingPage() {
  const [step, setStep] = useState(1);
  const [name, setName] = useState("");
  const [type, setType] = useState<(typeof TYPES)[number]["id"]>("supermarket");
  const [hasEmployees, setHasEmployees] = useState(false);
  const [sellsOnCredit, setSellsOnCredit] = useState(true);
  const [manageInventory, setManageInventory] = useState(true);
  const [usesBarcode, setUsesBarcode] = useState(false);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  const submit = async () => {
    setBusy(true);
    setError("");
    const res = await createBusiness({
      name,
      type,
      hasEmployees,
      sellsOnCredit,
      manageInventory,
      usesBarcode,
    });
    if (res && !res.ok) {
      setError(res.error);
      setBusy(false);
    }
  };

  return (
    <div className="fade-up rounded-3xl border border-white/10 bg-white/5 p-7 shadow-2xl backdrop-blur">
      <div className="mb-6 flex items-center justify-center gap-2">
        {[1, 2, 3].map((s) => (
          <span
            key={s}
            className={`h-1.5 rounded-full transition-all ${s === step ? "w-8 bg-emerald-400" : "w-4 bg-white/15"}`}
          />
        ))}
      </div>

      {step === 1 && (
        <div>
          <h2 className="mb-1 text-lg font-black text-white">إيه نوع نشاطك؟</h2>
          <p className="mb-5 text-xs text-slate-400">هنظبط النظام على طريقة شغلك — مش العكس.</p>
          <div className="space-y-2.5">
            {TYPES.map((t) => (
              <button
                key={t.id}
                onClick={() => setType(t.id)}
                className={`flex w-full items-start gap-3 rounded-2xl border p-4 text-right transition ${type === t.id ? "border-emerald-400/60 bg-emerald-500/10" : "border-white/10 bg-white/5 hover:border-white/20"}`}
              >
                <span className="text-2xl">{t.emoji}</span>
                <span className="min-w-0">
                  <span className="block text-sm font-extrabold text-white">{t.name}</span>
                  <span className="mt-0.5 block text-[11px] leading-4 text-slate-400">{t.desc}</span>
                </span>
                {type === t.id && <Icon name="check" size={18} className="mr-auto mt-1 shrink-0 text-emerald-400" />}
              </button>
            ))}
          </div>
          <Btn className="mt-5 w-full" size="lg" onClick={() => setStep(2)}>
            التالي
          </Btn>
        </div>
      )}

      {step === 2 && (
        <div>
          <h2 className="mb-1 text-lg font-black text-white">اسم المحل</h2>
          <p className="mb-5 text-xs text-slate-400">هو اللي هيظهر في الفواتير والتقارير.</p>
          <Input
            placeholder="مثال: سوبر ماركت النور"
            value={name}
            onChange={(e) => setName(e.target.value)}
            className="border-white/10 bg-white/5 text-white placeholder:text-slate-500"
          />
          <div className="mt-5 space-y-2">
            {[
              { key: "hasEmployees", label: "عندك موظفين بيشتغلوا معاك؟", value: hasEmployees, set: setHasEmployees, emoji: "👥" },
              { key: "sellsOnCredit", label: "بتبيع بالدين لبعض العملاء؟", value: sellsOnCredit, set: setSellsOnCredit, emoji: "📒" },
              { key: "manageInventory", label: "عايز تتابع المخزون والكميات؟", value: manageInventory, set: setManageInventory, emoji: "📦" },
              { key: "usesBarcode", label: "بتستخدم باركود في المحل؟", value: usesBarcode, set: setUsesBarcode, emoji: "🔢" },
            ].map((q) => (
              <button
                key={q.key}
                onClick={() => q.set(!q.value)}
                className={`flex w-full items-center gap-3 rounded-2xl border px-4 py-3 text-right transition ${q.value ? "border-emerald-400/60 bg-emerald-500/10" : "border-white/10 bg-white/5 hover:border-white/20"}`}
              >
                <span className="text-lg">{q.emoji}</span>
                <span className="flex-1 text-sm font-bold text-white">{q.label}</span>
                <span className={`flex h-6 w-11 items-center rounded-full p-0.5 transition ${q.value ? "bg-emerald-500" : "bg-white/15"}`}>
                  <span className={`h-5 w-5 rounded-full bg-white transition-transform ${q.value ? "-translate-x-5" : ""}`} />
                </span>
              </button>
            ))}
          </div>
          <div className="mt-5 flex gap-2">
            <Btn variant="outline" onClick={() => setStep(1)} className="flex-1 border-white/15 bg-transparent text-white hover:bg-white/10">
              رجوع
            </Btn>
            <Btn className="flex-1" size="lg" onClick={() => setStep(3)} disabled={!name.trim()}>
              التالي
            </Btn>
          </div>
        </div>
      )}

      {step === 3 && (
        <div className="text-center">
          <div className="mb-4 text-5xl">🎉</div>
          <h2 className="mb-2 text-lg font-black text-white">كل حاجة جاهزة!</h2>
          <p className="mx-auto mb-6 max-w-xs text-sm leading-6 text-slate-300">
            هنجهز لك «{name.trim() || "المحل"}» بالفئات والوحدات المناسبة لنشاطك.
            أول خطوة: افتح الخزنة وضيف أول منتج — وبعدها بيع في أقل من دقيقة.
          </p>
          {error && <p className="mb-3 rounded-xl bg-red-500/15 px-3 py-2 text-xs font-bold text-red-300">{error}</p>}
          <Btn className="w-full" size="lg" loading={busy} onClick={submit}>
            ابدأ الآن
          </Btn>
          <button onClick={() => setStep(2)} className="mt-3 text-xs font-bold text-slate-400 hover:text-white">
            تعديل الإجابات
          </button>
        </div>
      )}
    </div>
  );
}
