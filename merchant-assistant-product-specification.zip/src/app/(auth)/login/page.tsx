"use client";

import { useState } from "react";
import { Input, Btn, Icon } from "@/components/ui";
import { login } from "@/lib/engine";

export default function LoginPage() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setError("");
    const res = await login(email, password);
    if (res && !res.ok) {
      setError(res.error);
      setBusy(false);
    }
  };

  const demos = [
    { label: "أحمد — صاحب النشاط", email: "ahmed@demo.com", desc: "يشوف كل حاجة ويدير" },
    { label: "سارة — كاشير", email: "sara@demo.com", desc: "بيع وحسابات محدودة" },
    { label: "محمود — مدير", email: "mahmoud@demo.com", desc: "إدارة بدون موظفين" },
  ];

  return (
    <div className="fade-up rounded-3xl border border-white/10 bg-white/5 p-7 shadow-2xl backdrop-blur">
      <p className="mb-5 text-center text-sm font-bold text-slate-300">
        تجربة سريعة بحسابات جاهزة — كلمة المرور <span className="text-emerald-400">1234</span>
      </p>
      <div className="mb-5 grid gap-2">
        {demos.map((d) => (
          <button
            key={d.email}
            onClick={async () => {
              setBusy(true);
              setError("");
              const res = await login(d.email, "1234");
              if (res && !res.ok) {
                setError(res.error);
                setBusy(false);
              }
            }}
            disabled={busy}
            className="flex items-center gap-3 rounded-2xl border border-white/10 bg-white/5 px-4 py-3 text-right transition hover:border-emerald-400/40 hover:bg-emerald-500/10 disabled:opacity-50"
          >
            <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-emerald-500/20 text-emerald-300">
              <Icon name="customers" size={18} />
            </span>
            <span className="min-w-0 flex-1">
              <span className="block text-sm font-extrabold text-white">{d.label}</span>
              <span className="block text-[11px] text-slate-400">{d.desc}</span>
            </span>
            <Icon name="arrow" size={16} className="rotate-180 text-slate-500" />
          </button>
        ))}
      </div>
      <div className="mb-5 flex items-center gap-3">
        <span className="h-px flex-1 bg-white/10" />
        <span className="text-[11px] font-bold text-slate-500">أو سجل دخول بحسابك</span>
        <span className="h-px flex-1 bg-white/10" />
      </div>
      <form onSubmit={submit} className="space-y-3">
        <Input
          type="email"
          placeholder="البريد الإلكتروني"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          className="border-white/10 bg-white/5 text-white placeholder:text-slate-500"
          required
        />
        <Input
          type="password"
          placeholder="كلمة المرور"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          className="border-white/10 bg-white/5 text-white placeholder:text-slate-500"
          required
        />
        {error && (
          <p className="rounded-xl bg-red-500/15 px-3 py-2 text-xs font-bold text-red-300">{error}</p>
        )}
        <Btn type="submit" loading={busy} className="w-full" size="lg">
          دخول
        </Btn>
      </form>
      <p className="mt-5 text-center text-[11px] leading-5 text-slate-500">
        مفيش حساب؟ اكتب بريدك وكلمة مرور وسننشئ حسابك تلقائيًا — ولا حاجة لحفظ إعدادات معقدة.
      </p>
    </div>
  );
}
