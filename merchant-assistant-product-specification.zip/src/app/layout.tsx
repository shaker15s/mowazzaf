import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "مساعد التاجر — نظام تشغيل لمحلّك",
  description:
    "بيع بسرعة، اعرف فلوسك، تابع بضاعتك — نظام بسيط يفهم شغل التاجر الصغير بدل الورقة والقلم.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="ar" dir="rtl">
      <body className="bg-[#f6f5f2] text-slate-900 antialiased">{children}</body>
    </html>
  );
}
