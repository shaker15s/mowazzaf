/* تشغيل الزرع يدويًا: npx tsx scripts/seed.ts */
import "dotenv/config";
import { seedIfEmpty } from "../src/db/seed";

seedIfEmpty()
  .then((seeded) => {
    console.log(seeded ? "✅ تم زرع البيانات التجريبية" : "ℹ️ البيانات موجودة مسبقًا");
    process.exit(0);
  })
  .catch((e) => {
    console.error("❌ فشل الزرع:", e);
    process.exit(1);
  });
